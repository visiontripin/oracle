"""Bot core package."""
